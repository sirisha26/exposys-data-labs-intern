## Steps
- pip install --upgrade google-cloud-firestore
- Setup the environment variable GOOGLE_APPLICATION_CREDENTIALS as documented in https://developers.google.com/identity/protocols/application-default-credentials
- pip install names (for the add user script)